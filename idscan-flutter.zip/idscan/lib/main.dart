import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

const kPri = Color(0xFF6C5CE7);
void main() => runApp(const App());

class Scan {
  String id, path, name, nid, dob, gender, address;
  int ts;
  bool fav;
  Scan(this.id, this.path, this.ts,
      {this.name = '', this.nid = '', this.dob = '', this.gender = '', this.address = '', this.fav = false});
  Map<String, dynamic> toJson() => {'id': id, 'path': path, 'ts': ts, 'name': name, 'nid': nid, 'dob': dob, 'gender': gender, 'address': address, 'fav': fav};
  factory Scan.fromJson(Map<String, dynamic> j) => Scan(j['id'], j['path'], j['ts'],
      name: j['name'] ?? '', nid: j['nid'] ?? '', dob: j['dob'] ?? '', gender: j['gender'] ?? '', address: j['address'] ?? '', fav: j['fav'] ?? false);
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'ماسح البطاقات',
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
        theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: kPri), useMaterial3: true),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Scan> items = [];
  final sel = <String>{};
  bool busy = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('scans');
    if (s != null) items = (jsonDecode(s) as List).map((e) => Scan.fromJson(e)).toList();
    setState(() {});
  }

  Future<void> save() async => (await SharedPreferences.getInstance()).setString('scans', jsonEncode(items.map((e) => e.toJson()).toList()));
  void msg(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  String norm(String s) {
    const a = '٠١٢٣٤٥٦٧٨٩', b = '۰۱۲۳۴۵۶۷۸۹';
    var o = s;
    for (var i = 0; i < 10; i++) {
      o = o.replaceAll(a[i], '$i').replaceAll(b[i], '$i');
    }
    return o;
  }

  Future<void> add(List<XFile> files) async {
    setState(() => busy = true);
    final dir = await getApplicationDocumentsDirectory();
    Scan? last;
    for (final f in files) {
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final path = '${dir.path}/$id.jpg';
      await File(f.path).copy(path);
      final s = Scan(id, path, DateTime.now().millisecondsSinceEpoch);
      try {
        final text = await FlutterTesseractOcr.extractText(path, language: 'ara', args: {'psm': '6', 'preserve_interword_spaces': '1'});
        final n = norm(text);
        final m = RegExp(r'\d{14}').firstMatch(n.replaceAll(RegExp(r'\s'), ''));
        if (m != null) {
          s.nid = m.group(0)!;
          final c = int.parse(s.nid[0]);
          s.dob = '${c == 2 ? 19 : 20}${s.nid.substring(1, 3)}/${s.nid.substring(3, 5)}/${s.nid.substring(5, 7)}';
          s.gender = int.parse(s.nid[12]) % 2 == 1 ? 'ذكر' : 'أنثى';
        }
        final lines = text.split('\n').map((e) => e.trim()).where((e) => e.length > 2 && RegExp(r'[\u0600-\u06FF]').hasMatch(e) && !RegExp(r'[0-9٠-٩]').hasMatch(e)).toList();
        if (lines.isNotEmpty) s.name = lines.first;
        if (lines.length > 1) s.address = lines.skip(1).take(2).join(' ');
      } catch (e) {
        msg('تعذر الاستخراج التلقائي، أدخل البيانات يدوياً');
      }
      items.insert(0, s);
      last = s;
    }
    await save();
    setState(() => busy = false);
    if (files.length == 1 && last != null) edit(last);
  }

  void pick() => showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                  leading: const Icon(Icons.photo_camera),
                  title: const Text('تصوير بطاقة بالكاميرا'),
                  onTap: () async {
                    Navigator.pop(context);
                    final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 90);
                    if (x != null) add([x]);
                  }),
              ListTile(
                  leading: const Icon(Icons.photo_library),
                  title: const Text('اختيار عدة صور من المعرض'),
                  onTap: () async {
                    Navigator.pop(context);
                    final x = await ImagePicker().pickMultiImage(imageQuality: 90);
                    if (x.isNotEmpty) add(x);
                  }),
            ]),
          ));

  void edit(Scan s) {
    final k = {'name': 'الاسم', 'nid': 'الرقم القومي', 'dob': 'تاريخ الميلاد', 'gender': 'النوع', 'address': 'العنوان'};
    final cs = {for (final e in k.keys) e: TextEditingController(text: {'name': s.name, 'nid': s.nid, 'dob': s.dob, 'gender': s.gender, 'address': s.address}[e])};
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('بيانات البطاقة'),
              content: SingleChildScrollView(
                  child: Column(children: [
                Image.file(File(s.path), height: 150),
                for (final e in k.entries) TextField(controller: cs[e.key], decoration: InputDecoration(labelText: e.value)),
              ])),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
                FilledButton(
                    onPressed: () {
                      s.name = cs['name']!.text;
                      s.nid = cs['nid']!.text;
                      s.dob = cs['dob']!.text;
                      s.gender = cs['gender']!.text;
                      s.address = cs['address']!.text;
                      save();
                      setState(() {});
                      Navigator.pop(context);
                    },
                    child: const Text('حفظ')),
              ],
            ));
  }

  List<Scan> chosen() => items.where((e) => sel.contains(e.id)).toList();

  Future<void> sendPdf() async {
    final doc = pw.Document();
    for (final s in chosen()) {
      final img = pw.MemoryImage(await File(s.path).readAsBytes());
      doc.addPage(pw.Page(build: (_) => pw.Center(child: pw.Image(img, fit: pw.BoxFit.contain))));
    }
    final f = File('${(await getTemporaryDirectory()).path}/البطاقات.pdf');
    await f.writeAsBytes(await doc.save());
    await Share.shareXFiles([XFile(f.path)]);
  }

  Future<void> sendCsv() async {
    String q(String x) => '"${x.replaceAll('"', '""')}"';
    final rows = ['الاسم,الرقم القومي,تاريخ الميلاد,النوع,العنوان', for (final s in chosen()) [s.name, s.nid, s.dob, s.gender, s.address].map(q).join(',')];
    final f = File('${(await getTemporaryDirectory()).path}/بيانات-البطاقات.csv');
    await f.writeAsString('\uFEFF${rows.join('\r\n')}');
    await Share.shareXFiles([XFile(f.path)]);
  }

  Widget list(bool favOnly) {
    final l = items.where((e) => !favOnly || e.fav).toList();
    if (l.isEmpty) return const Center(child: Text('لا توجد ملفات بعد'));
    return ListView.separated(
      itemCount: l.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, i) {
        final s = l[i];
        final d = DateTime.fromMillisecondsSinceEpoch(s.ts);
        return ListTile(
          contentPadding: const EdgeInsets.all(12),
          leading: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(s.path), width: 64, height: 64, fit: BoxFit.cover)),
          title: Text(s.name.isEmpty ? 'بدون اسم' : s.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${s.nid.isEmpty ? 'مصر، بطاقة الهوية' : s.nid}\n${d.year}/${d.month}/${d.day} ${d.hour}:${d.minute.toString().padLeft(2, '0')}'),
          isThreeLine: true,
          selected: sel.contains(s.id),
          onTap: () => sel.isNotEmpty ? setState(() => sel.contains(s.id) ? sel.remove(s.id) : sel.add(s.id)) : edit(s),
          onLongPress: () => setState(() => sel.add(s.id)),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(icon: Icon(s.fav ? Icons.star : Icons.star_border, color: kPri), onPressed: () { s.fav = !s.fav; save(); setState(() {}); }),
            PopupMenuButton<String>(
                onSelected: (v) { if (v == 'del') { File(s.path).deleteSync(); items.remove(s); sel.remove(s.id); save(); setState(() {}); } else { edit(s); } },
                itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('تعديل')), PopupMenuItem(value: 'del', child: Text('حذف'))]),
          ]),
        );
      },
    );
  }

  @override
  Widget build(BuildContext c) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Text(sel.isEmpty ? 'الملفات الممسوحة ضوئياً' : '${sel.length} محدد'),
            actions: [
              if (sel.isNotEmpty) ...[
                IconButton(icon: const Icon(Icons.picture_as_pdf), tooltip: 'إرسال PDF', onPressed: sendPdf),
                IconButton(icon: const Icon(Icons.table_chart), tooltip: 'إرسال جدول', onPressed: sendCsv),
                IconButton(icon: const Icon(Icons.close), onPressed: () => setState(sel.clear)),
              ] else
                IconButton(icon: const Icon(Icons.select_all), tooltip: 'تحديد الكل', onPressed: () => setState(() => sel.addAll(items.map((e) => e.id)))),
            ],
            bottom: const TabBar(tabs: [Tab(text: 'جميع عمليات المسح الضوئي'), Tab(text: 'التفضيلات')]),
          ),
          body: busy ? const Center(child: CircularProgressIndicator()) : TabBarView(children: [list(false), list(true)]),
          floatingActionButton: FloatingActionButton.extended(
              onPressed: busy ? null : pick, backgroundColor: kPri, foregroundColor: Colors.white, icon: const Icon(Icons.add), label: const Text('ابدأ المسح الضوئي')),
        ),
      );
}
