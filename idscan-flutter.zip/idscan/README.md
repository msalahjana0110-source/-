# ماسح البطاقات (مفتوح المصدر)

## البناء
1. ثبّت Flutter ثم داخل المجلد: `flutter create . --platforms=android`
2. نزّل ملف `ara.traineddata` من مستودع tesseract-ocr/tessdata_fast على GitHub وضعه في `assets/tessdata/`
3. في `android/app/build.gradle` اجعل `minSdkVersion 21` (أو أعلى)
4. `flutter pub get` ثم `flutter build apk --release`
   الملف الناتج: `build/app/outputs/flutter-apk/app-release.apk`

## الاستخدام
- «ابدأ المسح الضوئي»: كاميرا أو عدة صور. يستخرج الرقم القومي ويحسب تاريخ الميلاد والنوع منه.
- ضغطة مطولة لتحديد عدة بطاقات، ثم أيقونة PDF أو الجدول لإرسالها كلها مرة واحدة.
- راجع الاسم والعنوان دائماً، لأن OCR العربي قد يخطئ.
